#ifndef cfeeny_test_cases_h
#define cfeeny_test_cases_h

Suite *create_suite_hashmap(void);
Suite *create_suite_vm(void);

#endif
